#ifndef SCHOOLEVENT_H
#define SCHOOLENENT_H
#include "Event.h"

class SchoolEvent: public Event
{
    public:
        SchoolEvent(string="");
//        ~SchoolEvent();
        bool lessThan(Event*);
//        bool school = true;
};

#endif
