#include "View.h"
#include <iostream>
using namespace std;

int View::dispMenu()
{
    int numOptions = 1;                                                                               
    int selection  = -1;                                                                              
                                                                                                    
    cout << endl;                                                                                     
    cout << "(1) Add Event" << endl;                                                                  
    cout << "(0) Exit" << endl;                                                                       
                                                                                                    
    while (selection < 0 || selection > numOptions) {                                                 
        cout << "Enter your selection: ";                                                               
        cin  >> selection;                                                                              
    }                                                                                                 
                                                                                                    
    return selection;
}

void View::readUser(string &eventName, int &hour, int &min, int &day, int &month, int &year)
{
    cout << "name of event: ";                                                                  
    cin  >> eventName;                                                                          
    cout << "hour:    ";                                                                        
    cin  >> hour;                                                                               
    cout << "minutes: ";                                                                        
    cin  >> min;                                                                                
    cout << "day:     ";                                                                        
    cin  >> day;                                                                                
    cout << "month:   ";                                                                        
    cin  >> month;                                                                              
    cout << "year:    ";                                                                        
    cin  >> year;
}

void View::printCalendar(Calendar *calendar)
{
     calendar->print();
}
