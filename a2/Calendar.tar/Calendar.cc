#include "Calendar.h"
#include "Event.h"
#include <iostream>
#include <string>

using namespace std;

Calendar::Calendar(string name)
        : calendarName(name){};

string Calendar::getCalendarName() const
{
    return calendarName; //return the name of calendar
}

void Calendar::changeCalendarName(string name)
{
    calendarName = name; //change the name of calendar
}

int Calendar::getEventNum() const
{
    return numEvents; //return the number of events currently in the calendar
}

void Calendar::addEvent(Event* event)
{
    //add new events into the calendar
    cout << endl <<  numEvents << endl;
    if(numEvents == 0)
        events[0]=event;
    else 
    {
        //compare the day of the events
        //from the end of the list
        int count = numEvents;
        for (int i=numEvents-1; i>=0; --i)
        {
            if(event->getDate()->lessThan(*(events[i]->getDate())))
            {
                //if the previous event larger than the current
                //then move the previous event towards to the end 
                //of the list, to make a hole for the current event
                events[i+1] = events[i];
                --count;
            }
            else
                break;
        }
        //insert the new event into the list
        events[count] = event;
    }
    ++numEvents;
}

void Calendar::print() const
{
    int count = numEvents;
    cout << endl << "Calendar Name: " << calendarName << endl;
    for(Event* e: events)
    {
        e->print();//print out all events in calendar
        --count;
        if(count==0)
        {
            cout << numEvents << " events in current calendar total." << endl;
            break;
        }
    }
}
void Calendar::clean()
{
    //destructor to delate all allocated memory in the heap
    for(int i=0; i<numEvents; ++i)
            delete events[i];
}
