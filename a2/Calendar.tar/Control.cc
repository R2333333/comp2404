#include "Control.h"
#include "Event.h"
#include <string>
#include "Calendar.h"

using namespace std;

void Control::launch()
{
    Calendar calendar("default");

    while (1) {                                                                                       
        menuSelection = view.dispMenu();                                                                     
                                                                                                    
        if (menuSelection == 0)                                                                         
        {                                                                                                                                                                              
            break;                                                                                      
        } 
        else if (menuSelection==1)
            view.readUser(eventName, hour, min, day, month, year);
        
        Event* newEvent = new Event(eventName);//Allocate the Event in heap
        newEvent->setDate(day, month, year, hour, min);//set the day of the event
        calendar.addEvent(newEvent);//add the event into the calendar
        }
    if (calendar.getEventNum() > 0)
        view.printCalendar(&calendar);
    calendar.clean();
}
